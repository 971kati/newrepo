//Regex email return true ou false
function validateEmail(email) {
  var re = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
  return re.test(email);
}
// Script pour le système de messages en direct
function sendMessage() {
  var message = $('#message-input').val();
  $('#live-chat').append('<p>' + message + '</p>');
  $('#message-input').val('');
}

// Script pour les commentaires vidéo
function sendComment() {
  var comment = $('#comment-input').val();
  $('#video-comments').append('<p>' + comment + '</p>');
  $('#comment-input').val('');
}
// Code JavaScript/jQuery ici
  // Par exemple, pour ajouter des commentaires dynamiquement:

$(document).ready(function () {
  $("#commentForm").submit(function (event) {
      event.preventDefault();
      var commentText = $("#comment").val();
      $("#commentList").append("<li>" + commentText + "</li>");
      $("#comment").val("");
  });
});
