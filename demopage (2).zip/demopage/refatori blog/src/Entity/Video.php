<?php

namespace App\Entity;

use App\src\Entity\Database;
use PDO;
use Exception;

class Video extends  Database
{
    private $id;
    private $title;
    private $type;
    private $url;
    private $liveComment;
    private $liveMessage;

    public function __construct($title, $type, $url, $liveComment = null, $liveMessage = null)
    {
        $this->title = $title;
        $this->type = $type;
        $this->url = $url;
        $this->liveComment = $liveComment;
        $this->liveMessage = $liveMessage;
    }

    // Getter et Setter pour l'ID
    public function getId()
    {
        return $this->id;
    }

    // Getter et Setter pour le titre
    public function getTitle()
    {
        return $this->title;
    }

    public function setTitle($title)
    {
        $this->title = $title;
    }

    // Getter et Setter pour le type
    public function getType()
    {
        return $this->type;
    }

    public function setType($type)
    {
        $this->type = $type;
    }

    // Getter et Setter pour l'URL
    public function getUrl()
    {
        return $this->url;
    }

    public function setUrl($url)
    {
        $this->url = $url;
    }

    // Getter et Setter pour le commentaire live
    public function getLiveComment()
    {
        return $this->liveComment;
    }

    public function setLiveComment($liveComment)
    {
        $this->liveComment = $liveComment;
    }

    // Getter et Setter pour le message live
    public function getLiveMessage()
    {
        return $this->liveMessage;
    }

    public function setLiveMessage($liveMessage)
    {
        $this->liveMessage = $liveMessage;
    }

    // Méthode pour enregistrer la vidéo en base de données
    public function save()
    {
        try {
            // Remplacez ces informations par les paramètres réels de votre base de données
            $host = 'localhost';
            $dbname = 'votre_base_de_donnees';
            $login = 'votre_utilisateur';
            $password = 'votre_mot_de_passe';

            $pdo = new PDO("mysql:host=$host;dbname=$dbname", $login, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt = $pdo->prepare('INSERT INTO videos (titre, type, url, commentaire_live, message_live) VALUES (?, ?, ?, ?, ?)');
            $stmt->execute([$this->title, $this->type, $this->url, $this->liveComment, $this->liveMessage]);

            $this->id = $pdo->lastInsertId();
        } catch (Exception $e) {
            echo 'Erreur : ' . $e->getMessage();
        }
    }
}

// Utilisez la classe Video