<?php
define("HOST", "localhost");
define("DBNAME", "blogsjt'");
define("LOGIN", "root"); //identifiant mysql
define("PASSWORD", ""); //password mysql