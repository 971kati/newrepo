-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : mer. 10 jan. 2024 à 12:18
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `blogsjt`
--

-- --------------------------------------------------------

--
-- Structure de la table `ajax_user`
--

CREATE TABLE `ajax_user` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `token` varchar(255) NOT NULL,
  `role` varchar(5) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Déchargement des données de la table `ajax_user`
--

INSERT INTO `ajax_user` (`id`, `email`, `pass`, `created_at`, `token`, `role`) VALUES
(1, 'a@gmail.com', '$2y$10$NIG.ZVoeyTz9rajqpN/t9O3Bye87fKLImUiwkRl003xn0EZV06e3q', '2023-10-31 09:22:34', 'A950JOfZx0', 'user'),
(0, 'axel@gmx.com', '$2y$10$eGo/KPcYkwI5cQf3fFZ2iOhN8tRwDWupUPt5vIL.jdRDq1yXY6N3.', '2023-12-15 09:55:23', 'yE74hVUocS', 'user'),
(0, 'ab@gmail.com', 'admin1', '2023-12-16 10:57:51', 'yE74hVUocS', 'user');

-- --------------------------------------------------------

--
-- Structure de la table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `contenu` text DEFAULT NULL,
  `date_publication` datetime DEFAULT NULL,
  `auteur` varchar(100) NOT NULL,
  `categorie` varchar(50) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE `categorie` (
  `id` int(11) NOT NULL,
  `libelle` varchar(512) NOT NULL,
  `logo` varchar(512) DEFAULT NULL,
  `Dev` varchar(520) NOT NULL,
  `Divers` varchar(520) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `pdo_article`
--

CREATE TABLE `pdo_article` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` longtext DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `state` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

--
-- Déchargement des données de la table `pdo_article`
--

INSERT INTO `pdo_article` (`id`, `title`, `content`, `img`, `state`, `created_at`) VALUES
(1, 'article1', 'Mon article favori', 'http://placehold.it/150x150', '1', '2020-08-03 15:07:20'),
(2, 'article2', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 15:07:20'),
(3, 'article3', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 15:07:20'),
(4, 'article4', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 15:07:20'),
(5, 'article5', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 15:07:20'),
(6, 'article6', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 15:07:20'),
(7, 'article7', 'Un article', 'http://placehold.it/150x150', '0', '2020-08-03 15:07:20'),
(8, 'article8', 'Un article', 'http://placehold.it/150x150', '0', '2020-08-03 15:07:20'),
(9, 'article9', 'Un article', 'http://placehold.it/150x150', '0', '2020-08-03 15:07:20'),
(10, 'article10', 'Un article', 'http://placehold.it/150x150', '0', '2020-08-03 15:07:20'),
(11, 'article1', 'Mon article favori', 'http://placehold.it/150x150', '1', '2020-08-03 17:07:20'),
(12, 'article2', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 17:07:20'),
(13, 'article3', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 17:07:20'),
(14, 'article4', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 17:07:20'),
(15, 'article5', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 17:07:20'),
(16, 'article6', 'Un article', 'http://placehold.it/150x150', '1', '2020-08-03 17:07:20'),
(17, 'article7', 'Un article', 'http://placehold.it/150x150', '0', '2020-08-03 17:07:20'),
(18, 'article8', 'Un article', 'http://placehold.it/150x150', '0', '2020-08-03 17:07:20'),
(19, 'article9', 'Un article', 'http://placehold.it/150x150', '0', '2020-08-03 17:07:20'),
(20, 'article10', 'Un article', 'http://placehold.it/150x150', '0', '2020-08-03 17:07:20');

-- --------------------------------------------------------

--
-- Structure de la table `portfolio`
--

CREATE TABLE `portfolio` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `videos`
--

CREATE TABLE `videos` (
  `id` int(11) NOT NULL,
  `titre` varchar(255) NOT NULL,
  `type` enum('live','preenregistre') NOT NULL,
  `url` varchar(255) NOT NULL,
  `commentaire_live` text DEFAULT NULL,
  `message_live` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `video_comments`
--

CREATE TABLE `video_comments` (
  `id` int(11) NOT NULL,
  `video_id` int(11) DEFAULT NULL,
  `commentaire` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

-- --------------------------------------------------------

--
-- Structure de la table `video_messages`
--

CREATE TABLE `video_messages` (
  `id` int(11) NOT NULL,
  `video_id` int(11) DEFAULT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=ascii COLLATE=ascii_general_ci;

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `pdo_article`
--
ALTER TABLE `pdo_article`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pour la table `pdo_article`
--
ALTER TABLE `pdo_article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
